============
CharmHelpers
============

CharmHelpers provides an opinionated set of tools for building Juju
charms that work together. In addition to basic tasks like interact-
ing with the charm environment and the machine it runs on, it also
helps keep you build hooks and establish relations effortlessly.
