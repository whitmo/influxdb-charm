"Tools for working with files injected into a charm just before deployment."
